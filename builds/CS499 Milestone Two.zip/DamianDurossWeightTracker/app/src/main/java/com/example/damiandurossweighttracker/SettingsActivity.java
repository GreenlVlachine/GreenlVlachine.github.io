package com.example.damiandurossweighttracker;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate; // dark-mode augment
import com.google.android.material.switchmaterial.SwitchMaterial; // dark-mode augment

public class SettingsActivity extends AppCompatActivity {

    private EditText phoneEditText;
    private Button saveButton;
    private SwitchMaterial darkModeSwitch; // dark-mode augment
    private SharedPreferences prefs; // declared outside of function to be used in isDarkMode and savedPhone

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE);

        // Initializes views
        phoneEditText = findViewById(R.id.phoneEditText);
        saveButton = findViewById(R.id.saveButton);

        // Initialize Dark Mode switch
        darkModeSwitch = findViewById(R.id.darkModeSwitch);

        darkModeSwitch.setOnCheckedChangeListener((buttonView, isChecked) -> {
            // Save dark mode pref
            prefs.edit().putBoolean("darkMode", isChecked).apply();

            // Apply dark or light theme
            AppCompatDelegate.setDefaultNightMode(
                    isChecked ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
            );
        });

        // Load saved dark mode pref
        boolean isDarkMode = prefs.getBoolean("darkMode", false);
        darkModeSwitch.setChecked(isDarkMode);
        AppCompatDelegate.setDefaultNightMode(
                isDarkMode ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );

        // Load and display saved phone number if exists
        // SharedPreferences prefs = getSharedPreferences("UserPrefs", MODE_PRIVATE); <-- this needed to be moved for appropriate scope
        String savedPhone = prefs.getString("phoneNumber", "");
        phoneEditText.setText(savedPhone);

        // Handle save button click
        saveButton.setOnClickListener(v -> {
            String phoneNumber = phoneEditText.getText().toString().trim();
            if (!phoneNumber.isEmpty()) {
                // Saves phone number to SharedPreferences
                prefs.edit().putString("phoneNumber", phoneNumber).apply();
                Toast.makeText(this, "Phone number saved", Toast.LENGTH_SHORT).show();
                finish(); // go back to DashboardActivity
            } else {
                Toast.makeText(this, "Please enter a phone number", Toast.LENGTH_SHORT).show();
            }
        });
    }
}