package com.example.damiandurossweighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class WeightDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "weight_db";
    private static final int DATABASE_VERSION = 1;

    private final FirebaseWeightHelper firebaseHelper;

    // Daily weight table
    public static final String TABLE_DAILY = "daily";
    public static final String COLUMN_DAILY_ID = "daily_id";
    public static final String COLUMN_DAILY_DATE = "daily_date";
    public static final String COLUMN_DAILY_WEIGHT = "daily_weight";
    public static final String COLUMN_DAILY_FIREBASE_ID = "firebase_id";

    // Goal weight table
    public static final String TABLE_GOAL = "goal";
    public static final String COLUMN_GOAL_ID = "goal_id";
    public static final String COLUMN_GOAL_WEIGHT = "goal_weight";

    public WeightDatabaseHelper(Context context, String username) {
        super(context, username + "_weightTracker.db", null, DATABASE_VERSION);
        this.firebaseHelper = new FirebaseWeightHelper(); // initialize Firebase helper
    }

    // Called when database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_DAILY_TABLE = "CREATE TABLE " + TABLE_DAILY + " (" +
                COLUMN_DAILY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_DAILY_DATE + " TEXT NOT NULL, " +
                COLUMN_DAILY_WEIGHT + " TEXT NOT NULL, " +
                COLUMN_DAILY_FIREBASE_ID + " TEXT)";

        String CREATE_GOAL_TABLE = "CREATE TABLE " + TABLE_GOAL + " (" +
                COLUMN_GOAL_ID + " INTEGER PRIMARY KEY, " +
                COLUMN_GOAL_WEIGHT + " TEXT NOT NULL)";

        db.execSQL(CREATE_DAILY_TABLE);
        db.execSQL(CREATE_GOAL_TABLE);
    }

    // Called when database version is incremented
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DAILY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GOAL);
        onCreate(db);
    }

    // Methods for Daily Weight Table
    public long insertDailyWeight(String date, String weight) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_DAILY_DATE, date);
        values.put(COLUMN_DAILY_WEIGHT, weight);
        long result = db.insert(TABLE_DAILY, null, values);

        if (result != -1) {
            firebaseHelper.addWeight(date, weight, (success, docId) -> {
                if (success && docId != null) {
                    ContentValues update = new ContentValues();
                    update.put(COLUMN_DAILY_FIREBASE_ID, docId);
                    db.update(TABLE_DAILY, update, COLUMN_DAILY_ID + "=?", new String[]{String.valueOf(result)});
                }
            });
        }
        return result;
    }

    public boolean updateDailyWeight(int id, String newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        // First, get the firebase_id for this row
        Cursor cursor = db.query(
                TABLE_DAILY,
                new String[]{COLUMN_DAILY_FIREBASE_ID},
                COLUMN_DAILY_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        String firebaseId = null;
        if (cursor.moveToFirst()) {
            firebaseId = cursor.getString(0);
        }
        cursor.close();

        // Update local SQLite
        ContentValues values = new ContentValues();
        values.put(COLUMN_DAILY_WEIGHT, newWeight);
        int result = db.update(TABLE_DAILY, values, COLUMN_DAILY_ID + "=?", new String[]{String.valueOf(id)});

        // Update Firestore entry by firebase_id
        if (result > 0 && firebaseId != null) {
            final String firebaseIdFinal = firebaseId;
            firebaseHelper.updateWeightById(firebaseIdFinal, newWeight, success ->
                    Log.d("FirebaseSync", success ?
                            "Updated Firestore weight for docId=" + firebaseIdFinal :
                            "Failed to update Firestore weight for docId=" + firebaseIdFinal)
            );
        }

        return result > 0;
    }

    public boolean deleteDailyWeight(int id) {
        SQLiteDatabase db = this.getWritableDatabase();

        // Get the firebase_id for the row we're deleting
        Cursor cursor = db.query(
                TABLE_DAILY,
                new String[]{COLUMN_DAILY_FIREBASE_ID},
                COLUMN_DAILY_ID + "=?",
                new String[]{String.valueOf(id)},
                null, null, null
        );

        String firebaseId = null;
        if (cursor.moveToFirst()) {
            firebaseId = cursor.getString(0);
        }
        cursor.close();

        // Delete locally
        int result = db.delete(TABLE_DAILY, COLUMN_DAILY_ID + "=?", new String[]{String.valueOf(id)});

        // Delete from Firebase by firebase_id
        if (result > 0 && firebaseId != null) {
            final String firebaseIdFinal = firebaseId;
            firebaseHelper.deleteWeightById(firebaseIdFinal, success ->
                    Log.d("FirebaseSync", success ? "Deleted Firebase weight (docId=" + firebaseIdFinal + ")" :
                            "Failed to delete Firebase weight (docId=" + firebaseIdFinal + ")")
            );
        }

        return result > 0;
    }

    public Cursor getAllDailyWeights() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_DAILY + " ORDER BY " + COLUMN_DAILY_DATE + " DESC", null);
    }

    // Methods for Goal Weight Table
    public boolean updateGoalWeight(float newWeight) {
        SQLiteDatabase db = this.getWritableDatabase();

        String weightString = String.valueOf(newWeight);

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_GOAL + " WHERE " + COLUMN_GOAL_ID + " = 1", null);

        ContentValues values = new ContentValues();
        values.put(COLUMN_GOAL_WEIGHT, weightString);

        long result;
        if (cursor.getCount() == 0) {
            result = db.insert(TABLE_GOAL, null, values);
        } else {
            result = db.update(TABLE_GOAL, values, COLUMN_GOAL_ID + "=?", new String[]{"1"});
        }
        cursor.close();
        return result != -1;
    }

    public String getGoalWeight() {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT " + COLUMN_GOAL_WEIGHT + " FROM " + TABLE_GOAL + " WHERE " + COLUMN_GOAL_ID + " = 1", null);
        if (cursor.moveToFirst()) {
            String weight = cursor.getString(0);
            cursor.close();
            return weight;
        }
        cursor.close();
        return null;
    }

    // Check if daily weight entry exists for given date
    public boolean entryExists(String date) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(
                TABLE_DAILY,
                new String[]{COLUMN_DAILY_ID},    // columns to return
                COLUMN_DAILY_DATE + " = ?",       // WHERE clause
                new String[]{date},               // WHERE args
                null, null, null
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}