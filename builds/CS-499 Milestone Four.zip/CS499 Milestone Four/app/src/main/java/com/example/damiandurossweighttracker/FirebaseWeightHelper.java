package com.example.damiandurossweighttracker;

import android.util.Log;
import androidx.annotation.NonNull;
import com.google.android.gms.common.util.BiConsumer;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.*;
import java.util.*;
import java.util.function.Consumer;

public class FirebaseWeightHelper {

    private final FirebaseFirestore db;
    private final String uid;

    public FirebaseWeightHelper() {
        this.db = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            this.uid = currentUser.getUid();
        } else {
            throw new IllegalStateException("User must be signed in before accessing FirebaseWeightHelper");
        }
    }

    private CollectionReference getUserWeightsCollection() {
        return db.collection("users").document(uid).collection("weights");
    }

    private DocumentReference getUserMetaDoc() {
        return db.collection("users").document(uid);
    }

    // Add or update weight entry
    public void addWeight(String date, String weight, BiConsumer<Boolean, String> onComplete) {
        Map<String, Object> data = new HashMap<>();
        data.put("date", date);
        data.put("weight", weight);

        // Let Firestore auto-generate a unique document ID
        getUserWeightsCollection()
                .add(data)
                .addOnSuccessListener(documentReference -> {
                    String docId = documentReference.getId(); // <-- store this in SQLite
                    Log.d("Firebase", "Weight added with docId: " + docId);
                    onComplete.accept(true, docId);
                })
                .addOnFailureListener(e -> {
                    Log.e("Firebase", "Error adding weight", e);
                    onComplete.accept(false, null);
                });
    }

    // Update weight safely
    public void updateWeightById(String docId, String newWeight, Consumer<Boolean> onComplete) {
        if (docId == null || docId.isEmpty()) {
            onComplete.accept(false);
            return;
        }

        getUserWeightsCollection()
                .document(docId)
                .update("weight", newWeight)
                .addOnSuccessListener(aVoid -> onComplete.accept(true))
                .addOnFailureListener(e -> {
                    Log.e("FirebaseWeightHelper", "Error updating weight for docId=" + docId, e);
                    onComplete.accept(false);
                });
    }

    // Delete weight safely
    public void deleteWeightById(String docId, OnSuccessListener<Boolean> callback) {
        if (docId == null || docId.isEmpty()) {
            callback.onSuccess(false);
            return;
        }

        getUserWeightsCollection()
                .document(docId)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Log.d("Firebase", "Deleted weight doc: " + docId);
                    callback.onSuccess(true);
                })
                .addOnFailureListener(e -> {
                    Log.e("FirebaseWeightHelper", "Failed to delete weight for user", e);
                    callback.onSuccess(false);
                });
    }

    // Fetch all weights
    public void getAllWeights(Consumer<List<WeightLogEntry>> onResult) {
        getUserWeightsCollection()
                .get()
                .addOnSuccessListener(snapshot -> {
                    List<WeightLogEntry> list = new ArrayList<>();
                    for (QueryDocumentSnapshot doc : snapshot) {
                        String date = doc.getString("date");
                        String weight = doc.getString("weight");
                        if (date != null && weight != null) {
                            list.add(new WeightLogEntry(0, date, weight));
                        }
                    }
                    onResult.accept(list);
                })
                .addOnFailureListener(e -> {
                    Log.e("Firebase", "Error fetching weights", e);
                    onResult.accept(new ArrayList<>());
                });
    }

    // Goal weight methods
    public void updateGoalWeight(float newGoal, Consumer<Boolean> onComplete) {
        Map<String, Object> data = new HashMap<>();
        data.put("goalWeight", newGoal);

        getUserMetaDoc().set(data, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    Log.d("Firebase", "Goal weight updated: " + newGoal);
                    onComplete.accept(true);
                })
                .addOnFailureListener(e -> {
                    Log.e("Firebase", "Error updating goal weight", e);
                    onComplete.accept(false);
                });
    }

    public void getGoalWeight(Consumer<String> onResult) {
        getUserMetaDoc().get()
                .addOnSuccessListener(snapshot -> {
                    if (snapshot.exists() && snapshot.contains("goalWeight")) {
                        Object goal = snapshot.get("goalWeight");
                        onResult.accept(goal != null ? goal.toString() : null);
                    } else {
                        onResult.accept(null);
                    }
                })
                .addOnFailureListener(e -> {
                    Log.e("Firebase", "Error fetching goal weight", e);
                    onResult.accept(null);
                });
    }
}