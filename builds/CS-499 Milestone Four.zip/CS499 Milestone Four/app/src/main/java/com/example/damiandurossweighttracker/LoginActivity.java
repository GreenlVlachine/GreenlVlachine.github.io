package com.example.damiandurossweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameEditText;
    private EditText passwordEditText;
    private Button loginButton;
    private Button createAccountButton;
    private UserDatabaseHelper dbHelper;
    private FirebaseAuth mAuth; // Firebase authentication

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_login);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.loginLayout), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI components
        usernameEditText = findViewById(R.id.usernameField);
        passwordEditText = findViewById(R.id.passwordField);
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.registerButton);
        // Initialize Database helper
        dbHelper = new UserDatabaseHelper(this);
        // Initialize Firebase Authentication
        mAuth = FirebaseAuth.getInstance();

        // Handle login button click
        loginButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString();
            String password = passwordEditText.getText().toString();

            // Input validation
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Try Firebase login first
            mAuth.signInWithEmailAndPassword(username, password)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            FirebaseUser user = mAuth.getCurrentUser();
                            Toast.makeText(LoginActivity.this, "Firebase login successful.", Toast.LENGTH_SHORT).show();
                            goToDashboard(username);
                        } else {
                            // Fall back to SQLite validation
                            if (dbHelper.validateUser(username, password)) {
                                goToDashboard(username);
                            } else {
                                Toast.makeText(LoginActivity.this, "Invalid credentials.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        });

        // Handle create account button click
        createAccountButton.setOnClickListener(v -> {
            String username = usernameEditText.getText().toString().trim();
            String password = passwordEditText.getText().toString().trim();

            // Input check
            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(LoginActivity.this, "Please enter username and password.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Prevent duplication
            if (doesUserExist(username)) {
                Toast.makeText(LoginActivity.this, "Username already exists.", Toast.LENGTH_SHORT).show();
            } else {
                // Create Firebase account too
                mAuth.createUserWithEmailAndPassword(username, password)
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                createNewUser(username, password);
                                Toast.makeText(LoginActivity.this, "Account created successfully.", Toast.LENGTH_SHORT).show();
                                goToDashboard(username);
                            } else {
                                Toast.makeText(LoginActivity.this, "Firebase signup failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
            }
        });
    }

    // Checks if username already exists
    private boolean doesUserExist(String username) {
        return dbHelper.userExists(username);
    }

    // Adds new user to database
    private void createNewUser(String username, String password) {
        dbHelper.insertUser(username, password);
    }

    private void goToDashboard(String username) {
        Intent intent = new Intent(LoginActivity.this, DashboardActivity.class);
        intent.putExtra("USERNAME", username);
        startActivity(intent);
        finish();
    }
}