package com.example.damiandurossweighttracker;

import android.app.AlertDialog;
import android.content.Context;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

// RecyclerView Adapter for displaying/managing list of daily weight entries
public class WeightLogAdapter extends RecyclerView.Adapter<WeightLogAdapter.ViewHolder> {

    private List<WeightLogEntry> weightLogEntries; // List of weight log entries
    private String username; // Username used to initialize dbHelper
    private DashboardActivity dashboardActivity; // Reference to dashboard for SMS perms

    public WeightLogAdapter(List<WeightLogEntry> weightLogEntries, String username, DashboardActivity dashboardActivity) {
        this.weightLogEntries = weightLogEntries;
        this.username = username;
        this.dashboardActivity = dashboardActivity;
    }

    // Inflates each item in RecylcerView with layout from item_weight_log.xml
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_weight_log, parent, false);
        return new ViewHolder(itemView);
    }

    // Binds data to each view item and sets up interaction logic for update/delete
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightLogEntry entry = weightLogEntries.get(position);
        holder.dateTextView.setText(entry.getDate());
        holder.weightTextView.setText(entry.getWeight());

        Context context = holder.itemView.getContext();
        WeightDatabaseHelper dbHelper = new WeightDatabaseHelper(context, username);

        // Handle delete button click
        holder.deleteButton.setOnClickListener(v -> {
            int currentPosition = holder.getAdapterPosition();
            if (currentPosition == RecyclerView.NO_POSITION) return;

            WeightLogEntry entryToDelete = weightLogEntries.get(currentPosition);
            Log.d("DeleteEntry", "Deleting ID: " + entry.getId());
            boolean deleted = dbHelper.deleteDailyWeight(entryToDelete.getId());

            if (deleted) {
                weightLogEntries.remove(currentPosition);
                notifyItemRemoved(currentPosition);
                Toast.makeText(context, "Entry deleted", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "Delete failed", Toast.LENGTH_SHORT).show();
            }
        });

        // Handle update button click (and displays dialog for update weight)
        holder.updateButton.setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("Update weight");

            final EditText input = new EditText(context);
            input.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
            input.setHint("e.g. 175.0");
            input.setText(entry.getWeight().replace(" lbs", ""));
            builder.setView(input);

            builder.setPositiveButton("OK", (dialog, which) -> {
                String updatedWeight = input.getText().toString().trim();

                if(!updatedWeight.isEmpty()) {
                    String weightFormatted = updatedWeight + " lbs";
                    boolean updated = dbHelper.updateDailyWeight(entry.getId(), weightFormatted);

                    if (updated) {
                        entry.setWeight(weightFormatted);
                        notifyItemChanged(position);
                        Toast.makeText(context, "Entry updated", Toast.LENGTH_SHORT).show();

                        // Check goal weight and send SMS if applicable
                        String goalWeight = dbHelper.getGoalWeight();
                        if (goalWeight != null && dashboardActivity.isSmsPermissionGranted) {
                            dashboardActivity.checkAndSendSmsIfGoalReached(weightFormatted);
                        }
                    } else {
                        Toast.makeText(context, "Update failed", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(context, "Please enter a weight", Toast.LENGTH_SHORT).show();
                }
            });

            builder.setNegativeButton("Cancel", (dialog, which) -> dialog.cancel());
            builder.show();
        });
    }

    // Called under the hood by RecyclerView when rendering the list, scrolling, add/update/delete, etc
    @Override
    public int getItemCount() {
        return weightLogEntries.size();
    }

    // ViewHolder class holds view for RecyclerView items
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView dateTextView;
        TextView weightTextView;
        ImageButton deleteButton;
        ImageButton updateButton;

        public ViewHolder(View itemView) {
            super(itemView);
            dateTextView = itemView.findViewById(R.id.dateTextView);
            weightTextView = itemView.findViewById(R.id.weightTextView);
            deleteButton = itemView.findViewById(R.id.deleteButton);
            updateButton = itemView.findViewById(R.id.updateButton);
        }
    }
}
