package com.example.damiandurossweighttracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class UserDatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "user_db";
    private static final int DATABASE_VERSION = 3;

    private static final String TABLE_USERS = "users";
    private static final String COLUMN_USERNAME = "username";
    private static final String COLUMN_PASSWORD = "password";

    public UserDatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    // Called when database is first created
    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_USERS_TABLE = "CREATE TABLE " + TABLE_USERS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COLUMN_USERNAME + " TEXT UNIQUE, " +
                COLUMN_PASSWORD + " TEXT)";
        db.execSQL(CREATE_USERS_TABLE);
    }

    // Called when database needs to be upgraded
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    // Checks if user with given username and password exists
    public boolean validateUser(String username, String password) {
        SQLiteDatabase db = this.getReadableDatabase();

        // hash the password prior to checking
        String hashedPassword = PasswordUtils.hashPassword(password);
        Log.d("DB_TEST", "Validating user: " + username + " | using hash=" + hashedPassword); // debugging code for security augment

        String query = "SELECT * FROM " + TABLE_USERS +
                " WHERE " + COLUMN_USERNAME + " = ? AND " + COLUMN_PASSWORD + " = ?";


        Cursor cursor = db.rawQuery(query, new String[]{username, hashedPassword});

        boolean exists = cursor.getCount() > 0;
        cursor.close();

        Log.d("DB_TEST", "Login success? " + exists); // debugging code for security augment
        return exists;
    }

    // Checks if username already exists in database
    public boolean userExists(String username) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM users WHERE username = ?", new String[]{username});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }

    // Inserts new username into database
    public void insertUser(String username, String password) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        String hashedPassword = PasswordUtils.hashPassword(password);
        values.put(COLUMN_USERNAME, username);
        values.put(COLUMN_PASSWORD, PasswordUtils.hashPassword(password)); // security augment - hash before storing

        Log.d("DB_TEST", "Inserting user: " + username + " | hashed=" + hashedPassword); // for ensuring hashing is working as intended
        db.insert(TABLE_USERS, null, values);
    }
}
